/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package jdbcapplication;

import java.sql.*;

public class Main {

    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        String url = "jdbc:mysql://localhost:3306/school";
        String user = "root";
        String password = "root#123";
        String query1 = "insert into students(name, age) values ('Kamal', 22)";
        String query2 = "select * from students";
        String query3 = "update students set name = 'New Kamal' where id = 2";
        String query4 = "delete from students where id = 1";
        
        //Register the driver
        Class.forName("com.mysql.cj.jdbc.Driver");
        
        //Create connection
        Connection conn = DriverManager.getConnection(url, user, password);
        if(conn != null)
            System.out.println("Connected");
        
        
        //Insert data into the db
//        Statement st1 = conn.createStatement();
//        int rowsInserted = st1.executeUpdate(query1);
//        
//        if(rowsInserted > 0){
//            System.out.println("Inserted successfully");
//        } else {
//            System.out.println("Not inserted successfully");
//        } 
        
        //Display values in the db
        Statement st2 = conn.createStatement();
        ResultSet result2 = st2.executeQuery(query2);
        
        while(result2.next()) {
            int id = result2.getInt("id");
            String name = result2.getString("name");
            int age = result2.getInt("age");
            
            System.out.println("ID: " + id);
            System.out.println("Name: " + name);
            System.out.println("Age: " + age); 
            System.out.println();
        }
        
        //Update values in the db
        PreparedStatement st3 = conn.prepareStatement(query3);
        int rowsUpdated = st3.executeUpdate();
        
        if(rowsUpdated > 0)
            System.out.println("An existing student was updated successfully");
        else
            System.out.println("Not updated successfully");
        
        
        System.out.println("\nUpdated data");
        Statement st4 = conn.createStatement();
        ResultSet result3 = st3.executeQuery(query2);
        
        while(result3.next()) {
            int id = result3.getInt("id");
            String name = result3.getString("name");
            int age = result3.getInt("age");
            
            System.out.println("ID: " + id);
            System.out.println("Name: " + name);
            System.out.println("Age: " + age); 
            System.out.println();
        }
        
        
        //Delete data
        PreparedStatement st5 = conn.prepareStatement(query4);
        int rowsDeleted = st5.executeUpdate();
        
        if(rowsDeleted > 0)
            System.out.println("An existing student has been removed");
        
        
        
    }
    
}
